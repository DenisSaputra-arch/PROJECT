package com.pwapika.bacaku.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

class CustomLineChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C2724A")
        style = Paint.Style.STROKE
        strokeWidth = 8f
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33C2724A") // 20% alpha brand color
        style = Paint.Style.FILL
    }

    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7A3B1F")
        style = Paint.Style.FILL
    }

    private val circleBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private var dataPoints = listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f)

    fun setData(points: List<Float>) {
        this.dataPoints = points
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        if (dataPoints.isEmpty()) return

        val width = width.toFloat()
        // leave space for stroke and circles
        val height = height.toFloat() - 24f 
        val paddingTop = 12f
        
        val maxVal = dataPoints.maxOrNull() ?: 1f
        val actualMax = if (maxVal == 0f) 1f else maxVal * 1.2f 

        val path = Path()
        val fillPath = Path()
        
        val stepX = width / (dataPoints.size - 1).coerceAtLeast(1)

        dataPoints.forEachIndexed { index, value ->
            val x = index * stepX
            val y = height - ((value / actualMax) * height) + paddingTop

            if (index == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, height + paddingTop)
                fillPath.lineTo(x, y)
            } else {
                val prevX = (index - 1) * stepX
                val prevY = height - ((dataPoints[index - 1] / actualMax) * height) + paddingTop
                
                val cpX1 = prevX + (x - prevX) / 2
                val cpY1 = prevY
                val cpX2 = prevX + (x - prevX) / 2
                val cpY2 = y
                
                path.cubicTo(cpX1, cpY1, cpX2, cpY2, x, y)
                fillPath.cubicTo(cpX1, cpY1, cpX2, cpY2, x, y)
            }
        }
        
        fillPath.lineTo(width, height + paddingTop)
        fillPath.close()

        canvas.drawPath(fillPath, fillPaint)
        canvas.drawPath(path, linePaint)

        dataPoints.forEachIndexed { index, value ->
            val x = index * stepX
            val y = height - ((value / actualMax) * height) + paddingTop
            
            canvas.drawCircle(x, y, 12f, circleBorderPaint)
            canvas.drawCircle(x, y, 8f, circlePaint)
        }
    }
}
