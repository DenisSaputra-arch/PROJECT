package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.pwapika.bacaku.adapter.NotifAdapter
import com.pwapika.bacaku.data.Notification
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivitySettingsBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var db: SQLiteHelper
    private lateinit var prefs: SharedPrefHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        prefs = SharedPrefHelper(this)

        binding.btnBack.setOnClickListener { finish() }

        binding.tvReminderTime.text = "${prefs.getReminderTime()} setiap hari"

        // Toggles
        binding.toggleReminder.isChecked = prefs.isReminderEnabled()
        binding.toggleReminder.setOnCheckedChangeListener { _, checked ->
            prefs.setReminderEnabled(checked)
        }

        binding.toggleDarkMode.isChecked = prefs.isDarkMode()
        binding.toggleDarkMode.setOnCheckedChangeListener { _, checked ->
            prefs.setDarkMode(checked)
            Toast.makeText(this, "Restart aplikasi untuk menerapkan mode gelap", Toast.LENGTH_SHORT).show()
        }

        // Language
        binding.rowLanguage.setOnClickListener {
            Toast.makeText(this, "Bahasa Indonesia aktif", Toast.LENGTH_SHORT).show()
        }

        // Load notifications
        loadNotifications()

        // Logout
        binding.btnLogout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Keluar Akun")
                .setMessage("Yakin ingin keluar?")
                .setPositiveButton("Keluar") { _, _ ->
                    prefs.logout()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finishAffinity()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun loadNotifications() {
        var notifications = db.getAllNotifications()
        if (notifications.isEmpty()) {
            // Add sample notifications
            db.addNotification(Notification(title = "Streak 7 hari! Mantap, jangan putus ya.", message = "", type = "streak"))
            db.addNotification(Notification(title = "Lanjut baca Atomic Habits?", message = "", type = "reminder"))
            db.addNotification(Notification(title = "Lencana baru: 1.000 Halaman terbuka.", message = "", type = "achievement"))
            notifications = db.getAllNotifications()
        }

        binding.rvNotif.layoutManager = LinearLayoutManager(this)
        binding.rvNotif.adapter = NotifAdapter(notifications) { notif ->
            db.markNotificationRead(notif.id)
            loadNotifications()
        }
    }
}
