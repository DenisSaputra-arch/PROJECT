package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityProfilBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class ProfilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfilBinding
    private lateinit var db: SQLiteHelper
    private lateinit var prefs: SharedPrefHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        prefs = SharedPrefHelper(this)

        loadProfile()
        setupMenu()
        setupBottomNav()

        binding.btnEditProfile.setOnClickListener {
            Toast.makeText(this, "Edit profil belum tersedia", Toast.LENGTH_SHORT).show()
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun loadProfile() {
        val userName = prefs.getUserName()
        val userEmail = prefs.getUserEmail()
        val initials = userName.split(" ").map { it.first() }.joinToString("").uppercase().take(2)

        binding.tvUserName.text = userName
        binding.tvUserEmail.text = userEmail
        binding.tvAvatar.text = initials

        // Stats
        val finished = db.getFinishedBookCount()
        val reading = db.getReadingBookCount()
        val target = prefs.getYearlyTarget()

        binding.tvStatSelesai.text = finished.toString()
        binding.tvStatSedang.text = reading.toString()
        binding.tvStatTarget.text = target.toString()
    }

    private fun setupMenu() {
        binding.rowTarget.setOnClickListener {
            startActivity(Intent(this, TargetBacaActivity::class.java))
        }

        binding.rowLencana.setOnClickListener {
            startActivity(Intent(this, AchievementsActivity::class.java))
        }

        binding.rowShare.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Lihat statistik bacaku di BacaKu App!")
            }
            startActivity(Intent.createChooser(intent, "Bagikan"))
        }

        binding.rowSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun setupBottomNav() {
        val navHome = binding.bottomNav.root.findViewById<View>(R.id.navHome)
        val navKoleksi = binding.bottomNav.root.findViewById<View>(R.id.navKoleksi)
        val navAdd = binding.bottomNav.root.findViewById<View>(R.id.navAdd)
        val navStatistik = binding.bottomNav.root.findViewById<View>(R.id.navStatistik)
        val navProfil = binding.bottomNav.root.findViewById<View>(R.id.navProfil)

        navHome?.setOnClickListener { startActivity(Intent(this, HomeActivity::class.java)); finish() }
        navKoleksi?.setOnClickListener { startActivity(Intent(this, KoleksiActivity::class.java)); finish() }
        navAdd?.setOnClickListener { startActivity(Intent(this, TambahBukuActivity::class.java)) }
        navStatistik?.setOnClickListener { startActivity(Intent(this, StatistikActivity::class.java)); finish() }
        navProfil?.setOnClickListener { /* already here */ }
    }
}
