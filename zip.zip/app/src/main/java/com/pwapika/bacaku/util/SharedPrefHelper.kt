package com.pwapika.bacaku.util

import android.content.Context
import android.content.SharedPreferences

class SharedPrefHelper(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREF_NAME = "bacaku_prefs"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_LOGGED_IN = "is_logged_in"
        private const val KEY_ONBOARDING_DONE = "onboarding_done"
        private const val KEY_YEARLY_TARGET = "yearly_target"
        private const val KEY_STREAK_DAYS = "streak_days"
        private const val KEY_TOTAL_PAGES = "total_pages"
        private const val KEY_BADGE_COUNT = "badge_count"
        private const val KEY_REMINDER_ENABLED = "reminder_enabled"
        private const val KEY_REMINDER_TIME = "reminder_time"
        private const val KEY_DARK_MODE = "dark_mode"
    }

    fun setLoggedIn(userId: Long, name: String, email: String) {
        prefs.edit().apply {
            putLong(KEY_USER_ID, userId)
            putString(KEY_USER_NAME, name)
            putString(KEY_USER_EMAIL, email)
            putBoolean(KEY_LOGGED_IN, true)
            apply()
        }
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)

    fun getUserId(): Long = prefs.getLong(KEY_USER_ID, -1)

    fun getUserName(): String = prefs.getString(KEY_USER_NAME, "Pembaca") ?: "Pembaca"

    fun getUserEmail(): String = prefs.getString(KEY_USER_EMAIL, "") ?: ""

    fun logout() {
        prefs.edit().clear().apply()
    }

    fun setOnboardingDone() {
        prefs.edit().putBoolean(KEY_ONBOARDING_DONE, true).apply()
    }

    fun isOnboardingDone(): Boolean = prefs.getBoolean(KEY_ONBOARDING_DONE, false)

    fun setYearlyTarget(target: Int) {
        prefs.edit().putInt(KEY_YEARLY_TARGET, target).apply()
    }

    fun getYearlyTarget(): Int = prefs.getInt(KEY_YEARLY_TARGET, 25)

    fun setStreakDays(days: Int) {
        prefs.edit().putInt(KEY_STREAK_DAYS, days).apply()
    }

    fun getStreakDays(): Int = prefs.getInt(KEY_STREAK_DAYS, 0)

    fun setTotalPages(pages: Int) {
        prefs.edit().putInt(KEY_TOTAL_PAGES, pages).apply()
    }

    fun getTotalPages(): Int = prefs.getInt(KEY_TOTAL_PAGES, 0)

    fun setBadgeCount(count: Int) {
        prefs.edit().putInt(KEY_BADGE_COUNT, count).apply()
    }

    fun getBadgeCount(): Int = prefs.getInt(KEY_BADGE_COUNT, 0)

    fun setReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_REMINDER_ENABLED, enabled).apply()
    }

    fun isReminderEnabled(): Boolean = prefs.getBoolean(KEY_REMINDER_ENABLED, true)

    fun setReminderTime(time: String) {
        prefs.edit().putString(KEY_REMINDER_TIME, time).apply()
    }

    fun getReminderTime(): String = prefs.getString(KEY_REMINDER_TIME, "20:00") ?: "20:00"

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }

    fun isDarkMode(): Boolean = prefs.getBoolean(KEY_DARK_MODE, false)
}
