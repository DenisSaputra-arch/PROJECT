package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityHomeBinding
import com.pwapika.bacaku.util.DateUtil
import com.pwapika.bacaku.util.SharedPrefHelper

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var db: SQLiteHelper
    private lateinit var prefs: SharedPrefHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        prefs = SharedPrefHelper(this)

        // Check login
        if (!prefs.isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Load data
        loadHomeData()

        // Navigation
        setupNavigation()

        // Notif button
        binding.btnNotif.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // See all
        binding.tvSeeAll.setOnClickListener {
            startActivity(Intent(this, KoleksiActivity::class.java))
        }

        // Current book card
        binding.cardCurrentBook.root.setOnClickListener {
            val books = db.getBooksByStatus("Sedang")
            if (books.isNotEmpty()) {
                val intent = Intent(this, DetailBukuActivity::class.java)
                intent.putExtra("book_id", books[0].id)
                startActivity(intent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadHomeData()
    }

    private fun loadHomeData() {
        // Date & greeting
        binding.tvDate.text = DateUtil.getFullDate().uppercase()
        binding.tvUserName.text = prefs.getUserName()

        // Hero stats
        val finished = db.getFinishedBookCount()
        val target = prefs.getYearlyTarget()
        val percent = if (target > 0) (finished * 100 / target) else 0

        binding.tvFinishedCount.text = finished.toString()
        binding.tvTargetTotal.text = "/$target"
        binding.tvHeroSubtitle.text = "Buku selesai \u00b7 ${target - finished} lagi menuju target"
        binding.tvProgressPercent.text = "$percent%"
        binding.progressBar.progress = percent
        binding.progressCircle.progress = percent

        val monthsLeft = DateUtil.getRemainingMonths()
        val booksPerMonth = if (monthsLeft > 0) (target - finished + monthsLeft - 1) / monthsLeft else 0
        binding.tvMonthsLeft.text = "$monthsLeft bulan tersisa"
        binding.tvBooksPerMonth.text = "\u2248 $booksPerMonth buku/bulan"

        // Stats
        binding.tvStreak.text = prefs.getStreakDays().toString()
        binding.tvTotalPages.text = db.getTotalPagesRead().toString()
        binding.tvBadgeCount.text = prefs.getBadgeCount().toString()

        // Currently reading
        val readingBooks = db.getBooksByStatus("Sedang")
        if (readingBooks.isNotEmpty()) {
            val book = readingBooks[0]
            setupCurrentBookCard(book)
        }

        // Nav active state
        setNavActive("home")
    }

    private fun setupCurrentBookCard(book: Book) {
        // The included layout is bound separately - use findViewById on the included view
        val cardView = findViewById<View>(R.id.cardCurrentBook)
        val tvTitle = cardView?.findViewById<android.widget.TextView>(R.id.tvBookTitle)
        val tvAuthor = cardView?.findViewById<android.widget.TextView>(R.id.tvBookAuthor)
        val tvPages = cardView?.findViewById<android.widget.TextView>(R.id.tvPageProgress)
        val tvPercent = cardView?.findViewById<android.widget.TextView>(R.id.tvPercent)

        tvTitle?.text = book.title
        tvAuthor?.text = book.author
        tvPages?.text = "Hal ${book.currentPage} / ${book.totalPages}"
        tvPercent?.text = "${book.progressPercent}%"
    }

    private fun setupNavigation() {
        binding.navKoleksi.setOnClickListener {
            startActivity(Intent(this, KoleksiActivity::class.java))
        }
        binding.navAdd.setOnClickListener {
            startActivity(Intent(this, TambahBukuActivity::class.java))
        }
        binding.navStatistik.setOnClickListener {
            startActivity(Intent(this, StatistikActivity::class.java))
        }
        binding.navProfil.setOnClickListener {
            startActivity(Intent(this, ProfilActivity::class.java))
        }
    }

    private fun setNavActive(active: String) {
        // Visual feedback handled by layout
    }
}
