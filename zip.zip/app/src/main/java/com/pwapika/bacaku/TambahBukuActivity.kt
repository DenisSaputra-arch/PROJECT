package com.pwapika.bacaku

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityTambahBukuBinding

class TambahBukuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTambahBukuBinding
    private lateinit var db: SQLiteHelper
    private var selectedStatus = "Sedang"
    
    private val categories = arrayOf("Self-Help", "Fiksi", "Bisnis", "Sejarah", "Biografi", "Sains")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTambahBukuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)

        binding.btnBack.setOnClickListener { finish() }
        
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories)
        binding.etCategory.setAdapter(adapter)

        setupStatusButtons()

        binding.btnSave.setOnClickListener { saveBook() }
    }

    private fun setupStatusButtons() {
        binding.btnMauDibaca.setOnClickListener {
            selectedStatus = "Mau Dibaca"
            updateStatusUI()
        }
        binding.btnSedang.setOnClickListener {
            selectedStatus = "Sedang"
            updateStatusUI()
        }
        binding.btnSelesai.setOnClickListener {
            selectedStatus = "Selesai"
            updateStatusUI()
        }
    }

    private fun updateStatusUI() {
        binding.btnMauDibaca.setBackgroundResource(if (selectedStatus == "Mau Dibaca") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnMauDibaca.setTextColor(if (selectedStatus == "Mau Dibaca") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.btnSedang.setBackgroundResource(if (selectedStatus == "Sedang") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnSedang.setTextColor(if (selectedStatus == "Sedang") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.btnSelesai.setBackgroundResource(if (selectedStatus == "Selesai") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnSelesai.setTextColor(if (selectedStatus == "Selesai") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))
    }

    private fun saveBook() {
        val title = binding.etTitle.text.toString().trim()
        val author = binding.etAuthor.text.toString().trim()
        val category = binding.etCategory.text.toString().trim().ifEmpty { "Self-Help" }
        val totalPages = binding.etTotalPages.text.toString().toIntOrNull() ?: 0
        val notes = binding.etNotes.text.toString().trim()

        if (title.isEmpty() || author.isEmpty()) {
            Toast.makeText(this, "Judul dan penulis wajib diisi", Toast.LENGTH_SHORT).show()
            return
        }

        val book = Book(
            title = title,
            author = author,
            category = category,
            totalPages = totalPages,
            status = selectedStatus,
            notes = notes,
            coverColor = getRandomCoverColor()
        )

        val id = db.addBook(book)
        if (id > 0) {
            Toast.makeText(this, "Buku berhasil ditambahkan!", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Gagal menambahkan buku", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getRandomCoverColor(): String {
        val colors = listOf("brown", "sage", "navy", "plum", "mustard", "rust", "teal", "ink")
        return colors.random()
    }
}
