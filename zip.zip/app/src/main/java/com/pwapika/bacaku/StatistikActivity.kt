package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityStatistikBinding
import com.pwapika.bacaku.util.DateUtil

class StatistikActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatistikBinding
    private lateinit var db: SQLiteHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatistikBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)

        setupTabs()
        loadStats()
        setupBottomNav()

        // binding.btnBack.setOnClickListener { finish() }
    }

    private fun setupTabs() {
        binding.tabMinggu.setOnClickListener { selectPeriod("Minggu") }
        binding.tabBulan.setOnClickListener { selectPeriod("Bulan") }
        binding.tabTahun.setOnClickListener { selectPeriod("Tahun") }
    }

    private fun selectPeriod(period: String) {
        binding.tabMinggu.setBackgroundResource(if (period == "Minggu") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabMinggu.setTextColor(if (period == "Minggu") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabBulan.setBackgroundResource(if (period == "Bulan") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabBulan.setTextColor(if (period == "Bulan") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabTahun.setBackgroundResource(if (period == "Tahun") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabTahun.setTextColor(if (period == "Tahun") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))
    }

    private fun loadStats() {
        // Total pages
        val totalPages = db.getTotalPagesRead()
        binding.tvTotalPages.text = "$totalPages hal"

        // Active days (demo)
        binding.tvActiveDays.text = "112 hari aktif"
        
        // Line chart data (demo)
        binding.lineChart.setData(listOf(15f, 40f, 20f, 65f, 35f, 85f, 50f))

        // Genre distribution
        val genres = db.getGenreDistribution()
        setupGenreBars(genres)
    }

    private fun setupGenreBars(genres: Map<String, Int>) {
        val maxCount = genres.values.maxOrNull() ?: 1

        genres.entries.forEachIndexed { index, (genre, count) ->
            when (index) {
                0 -> {
                    binding.tvGenre1.text = genre
                    binding.tvGenre1Count.text = "$count buku"
                    val percent = (count * 100 / maxCount)
                    binding.barGenre1.progress = percent
                }
                1 -> {
                    binding.tvGenre2.text = genre
                    binding.tvGenre2Count.text = "$count buku"
                    val percent = (count * 100 / maxCount)
                    binding.barGenre2.progress = percent
                }
                2 -> {
                    binding.tvGenre3.text = genre
                    binding.tvGenre3Count.text = "$count buku"
                    val percent = (count * 100 / maxCount)
                    binding.barGenre3.progress = percent
                }
            }
        }
    }

    private fun setupBottomNav() {
        val navHome = binding.bottomNav.root.findViewById<View>(R.id.navHome)
        val navKoleksi = binding.bottomNav.root.findViewById<View>(R.id.navKoleksi)
        val navAdd = binding.bottomNav.root.findViewById<View>(R.id.navAdd)
        val navStatistik = binding.bottomNav.root.findViewById<View>(R.id.navStatistik)
        val navProfil = binding.bottomNav.root.findViewById<View>(R.id.navProfil)

        navHome?.setOnClickListener { startActivity(Intent(this, HomeActivity::class.java)); finish() }
        navKoleksi?.setOnClickListener { startActivity(Intent(this, KoleksiActivity::class.java)); finish() }
        navAdd?.setOnClickListener { startActivity(Intent(this, TambahBukuActivity::class.java)) }
        navStatistik?.setOnClickListener { /* already here */ }
        navProfil?.setOnClickListener { startActivity(Intent(this, ProfilActivity::class.java)); finish() }
    }
}
