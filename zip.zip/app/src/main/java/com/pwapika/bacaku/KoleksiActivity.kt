package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.pwapika.bacaku.adapter.BookAdapter
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityKoleksiBinding

class KoleksiActivity : AppCompatActivity() {

    private lateinit var binding: ActivityKoleksiBinding
    private lateinit var db: SQLiteHelper
    private var currentTab = "Sedang"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKoleksiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        binding.rvBooks.layoutManager = LinearLayoutManager(this)

        setupTabs()
        loadBooks()

        binding.btnBack.setOnClickListener { finish() }
        binding.btnAddBook.setOnClickListener {
            startActivity(Intent(this, TambahBukuActivity::class.java))
        }
        binding.btnEmptyAdd.setOnClickListener {
            startActivity(Intent(this, TambahBukuActivity::class.java))
        }
        binding.btnEmptyExplore.setOnClickListener {
            startActivity(Intent(this, CariActivity::class.java))
        }
        binding.etSearch.setOnEditorActionListener { _, _, _ ->
            searchBooks(binding.etSearch.text.toString())
            true
        }
        setupBottomNav()
    }

    override fun onResume() {
        super.onResume()
        loadBooks()
        updateTabCounts()
    }

    private fun setupTabs() {
        binding.tabSedang.setOnClickListener { switchTab("Sedang") }
        binding.tabSelesai.setOnClickListener { switchTab("Selesai") }
        binding.tabWishlist.setOnClickListener { switchTab("Wishlist") }
    }

    private fun switchTab(tab: String) {
        currentTab = tab
        binding.tabSedang.setBackgroundResource(if (tab == "Sedang") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabSedang.setTextColor(if (tab == "Sedang") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabSelesai.setBackgroundResource(if (tab == "Selesai") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabSelesai.setTextColor(if (tab == "Selesai") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabWishlist.setBackgroundResource(if (tab == "Wishlist") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabWishlist.setTextColor(if (tab == "Wishlist") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        loadBooks()
    }

    private fun loadBooks() {
        val books = db.getBooksByStatus(currentTab)
        if (books.isEmpty()) {
            binding.rvBooks.visibility = android.view.View.GONE
            binding.layoutEmpty.visibility = android.view.View.VISIBLE
        } else {
            binding.rvBooks.visibility = android.view.View.VISIBLE
            binding.layoutEmpty.visibility = android.view.View.GONE
            binding.rvBooks.adapter = BookAdapter(books) { book ->
                val intent = Intent(this, DetailBukuActivity::class.java)
                intent.putExtra("book_id", book.id)
                startActivity(intent)
            }
        }
    }

    private fun showEmptyState() {
        // Obsolete
    }

    private fun searchBooks(query: String) {
        if (query.isEmpty()) {
            loadBooks()
            return
        }
        val books = db.searchBooks(query)
        binding.rvBooks.adapter = BookAdapter(books) { book ->
            val intent = Intent(this, DetailBukuActivity::class.java)
            intent.putExtra("book_id", book.id)
            startActivity(intent)
        }
    }

    private fun updateTabCounts() {
        val sedangCount = db.getBooksByStatus("Sedang").size
        val selesaiCount = db.getBooksByStatus("Selesai").size
        val wishlistCount = db.getBooksByStatus("Wishlist").size
        binding.tabSedang.text = "Sedang \u00b7 $sedangCount"
        binding.tabSelesai.text = "Selesai \u00b7 $selesaiCount"
        binding.tabWishlist.text = "Wishlist \u00b7 $wishlistCount"
    }

    private fun setupBottomNav() {
        val navHome = binding.bottomNav.root.findViewById<View>(R.id.navHome)
        val navKoleksi = binding.bottomNav.root.findViewById<View>(R.id.navKoleksi)
        val navAdd = binding.bottomNav.root.findViewById<View>(R.id.navAdd)
        val navStatistik = binding.bottomNav.root.findViewById<View>(R.id.navStatistik)
        val navProfil = binding.bottomNav.root.findViewById<View>(R.id.navProfil)

        navHome?.setOnClickListener { startActivity(Intent(this, HomeActivity::class.java)); finish() }
        navKoleksi?.setOnClickListener { /* already here */ }
        navAdd?.setOnClickListener { startActivity(Intent(this, TambahBukuActivity::class.java)) }
        navStatistik?.setOnClickListener { startActivity(Intent(this, StatistikActivity::class.java)); finish() }
        navProfil?.setOnClickListener { startActivity(Intent(this, ProfilActivity::class.java)); finish() }
    }
}
