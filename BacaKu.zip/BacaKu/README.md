# BacaKu - Jurnal & Tracker Bacaan

Aplikasi Android jurnal dan tracker bacaan pribadi. Dibangun dengan Kotlin, XML Layout, SQLite, dan mengikuti design system Figma secara ketat.

## Tech Stack

- **Android Studio** (Giraffe atau lebih baru)
- **Kotlin** 1.9+
- **XML Layout** (bukan Jetpack Compose)
- **ViewBinding** untuk view access
- **SQLite Database** (bukan Room) untuk penyimpanan lokal
- **RecyclerView + CardView** untuk list
- **Material Design 3** components
- **SharedPreferences** untuk session data
- **Intent** untuk navigasi antar Activity
- **Minimum SDK 24**

## Struktur Project

```
com.pwapika.bacaku/
├── data/
│   ├── Book.kt                 # Model Buku
│   ├── Quote.kt                # Model Kutipan/Catatan
│   ├── Achievement.kt          # Model Lencana
│   ├── User.kt                 # Model User
│   ├── Notification.kt         # Model Notifikasi
│   ├── ReadingSession.kt       # Model Sesi Baca
│   └── SQLiteHelper.kt         # Database Helper (CRUD)
├── adapter/
│   ├── BookAdapter.kt          # Adapter untuk list buku
│   ├── ShelfAdapter.kt         # Adapter untuk shelf/rak buku
│   ├── QuoteAdapter.kt         # Adapter untuk kutipan
│   ├── AchievementAdapter.kt   # Adapter untuk lencana
│   └── NotifAdapter.kt         # Adapter untuk notifikasi
├── util/
│   ├── SharedPrefHelper.kt     # Helper untuk SharedPreferences
│   └── DateUtil.kt             # Utility untuk format tanggal
├── SplashActivity.kt           # Splash Screen
├── OnboardingActivity.kt       # Onboarding 3 step
├── LoginActivity.kt            # Login
├── RegisterActivity.kt         # Register
├── HomeActivity.kt             # Beranda (dengan bottom nav)
├── KoleksiActivity.kt          # Koleksi Buku (tab: Sedang/Selesai/Wishlist)
├── CariActivity.kt             # Discover/Search
├── DetailBukuActivity.kt       # Detail Buku
├── TambahBukuActivity.kt       # Tambah Buku Baru
├── EditBukuActivity.kt         # Edit Buku
├── SesiBacaActivity.kt         # Timer Sesi Baca
├── StatistikActivity.kt        # Statistik (chart, heatmap, genre)
├── AchievementsActivity.kt     # Lencana Pencapaian
├── ProfilActivity.kt           # Profil User
├── SettingsActivity.kt         # Pengaturan & Notifikasi
├── TargetBacaActivity.kt       # Set Target Baca
├── CatatanKutipanActivity.kt   # Catatan & Kutipan
└── TentangActivity.kt          # Tentang Aplikasi
```

## 20 Frame yang Diimplementasikan

| No | Frame | Activity |
|----|-------|----------|
| 01 | Splash Screen | SplashActivity |
| 02 | Onboarding | OnboardingActivity |
| 03 | Login | LoginActivity |
| 04 | Home / Beranda | HomeActivity |
| 05 | Koleksi Buku | KoleksiActivity |
| 06 | Discover (Cari) | CariActivity |
| 07 | Detail Buku | DetailBukuActivity |
| 08 | Tambah Buku | TambahBukuActivity |
| 09 | Sesi Baca | SesiBacaActivity |
| 10 | Statistik | StatistikActivity |
| 11 | Lencana | AchievementsActivity |
| 12 | Profil | ProfilActivity |
| 13 | Pengaturan | SettingsActivity |
| 14 | Empty State | (built-in ke KoleksiActivity) |
| 15 | Skeleton | (built-in ke semua list) |
| 16 | Target Baca | TargetBacaActivity |
| 17 | Catatan & Kutipan | CatatanKutipanActivity |
| 18 | Register | RegisterActivity |
| 19 | Tentang | TentangActivity |
| 20 | Design System | (applied ke colors, themes, drawables) |

## Fitur

### Autentikasi
- Login dengan email/password (SQLite)
- Register akun baru
- Onboarding 3-step untuk pengguna pertama

### Manajemen Buku (CRUD Lengkap)
- Tambah buku baru dengan cover color
- Edit detail buku
- Hapus buku
- Update progress membaca via slider
- Search buku
- Kategori: Self-Help, Fiksi, Bisnis, Sains

### Koleksi
- 3 Tab: Sedang Dibaca, Selesai, Wishlist
- Counter per tab
- Empty state handling

### Sesi Baca
- Timer real-time
- Estimasi halaman terbaca
- Tracking harian & mingguan

### Statistik
- Halaman per hari (bar chart)
- Heatmap tahunan
- Distribusi genre favorit

### Lencana
- Sistem achievement dengan progress
- Unlocked & locked badges

### Catatan & Kutipan
- Tab: Semua, Kutipan, Catatan
- Search functionality

### Target Baca
- Periode: Harian/Mingguan/Tahunan
- Slider menit baca
- Counter buku per bulan
- Estimasi tahunan

### Settings
- Toggle reminder & dark mode
- Bahasa
- Notifikasi terbaru
- Logout

## Cara Menjalankan

1. Buka project ini di **Android Studio** (versi Giraffe atau lebih baru)
2. Tunggu Gradle sync selesai
3. Klik tombol **Run** atau tekan `Shift + F10`
4. Pilih emulator atau device fisik (minimum Android 7.0 / API 24)

## Design System

Design system dari Figma telah diimplementasikan secara ketat:

### Warna
- **Background**: `#F6F1EA` (warm cream)
- **Surface**: `#FFFFFF` (pure white)
- **Brand**: `#7A3B1F` (terracotta dark)
- **Brand-2**: `#C2724A` (terracotta light)
- **Accent**: `#3F5D45` (sage)
- **Gold**: `#C9A24A` (gold)
- **Ink**: `#1B1410` (near black)
- **Muted**: `#9A8A80` (warm gray)
- **Line**: `#EADFD3` (border)

### Typography
- Display: 28sp bold
- H1: 24sp bold
- H2: 18sp bold
- H3: 15sp bold
- Body: 14sp (line-height 1.55)
- Sub: 13sp
- Caption: 11.5sp
- Eyebrow: 11sp bold uppercase letter-spacing 0.12

### Shape & Elevation
- Cards: 16dp radius, 2dp elevation, 1dp border
- Buttons: 999dp radius (pill shape)
- Inputs: 12dp radius
- Cover books: 8dp radius
