package com.pwapika.bacaku.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pwapika.bacaku.R
import com.pwapika.bacaku.data.Book

class BookAdapter(
    private val books: List<Book>,
    private val onClick: (Book) -> Unit
) : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    class BookViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flCover: FrameLayout = itemView.findViewById(R.id.flCover)
        val tvCoverTitle: TextView = itemView.findViewById(R.id.tvCoverTitle)
        val tvBookTitle: TextView = itemView.findViewById(R.id.tvBookTitle)
        val tvBookAuthor: TextView = itemView.findViewById(R.id.tvBookAuthor)
        val tvPageProgress: TextView = itemView.findViewById(R.id.tvPageProgress)
        val tvPercent: TextView = itemView.findViewById(R.id.tvPercent)
        val progressMini: View = itemView.findViewById(R.id.progressMini)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_book_horizontal, parent, false)
        return BookViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val book = books[position]

        holder.tvBookTitle.text = book.title
        holder.tvBookAuthor.text = book.author
        holder.tvPageProgress.text = "${book.currentPage} / ${book.totalPages}"
        holder.tvPercent.text = "${book.progressPercent}%"
        holder.tvCoverTitle.text = book.title.replace(" ", "\n")

        // Set cover color
        val coverRes = when (book.coverColor) {
            "sage" -> R.drawable.bg_cover_sage
            "navy" -> R.drawable.bg_cover_navy
            "plum" -> R.drawable.bg_cover_plum
            "mustard" -> R.drawable.bg_cover_mustard
            "rust" -> R.drawable.bg_cover_rust
            "teal" -> R.drawable.bg_cover_teal
            "ink" -> R.drawable.bg_cover_ink
            else -> R.drawable.bg_cover_brown
        }
        holder.flCover.setBackgroundResource(coverRes)

        // Set progress bar width
        val layoutParams = holder.progressMini.layoutParams
        if (layoutParams is FrameLayout.LayoutParams) {
            layoutParams.width = (holder.itemView.width * book.progressPercent / 100)
            holder.progressMini.layoutParams = layoutParams
        }

        holder.itemView.setOnClickListener { onClick(book) }
    }

    override fun getItemCount(): Int = books.size
}
