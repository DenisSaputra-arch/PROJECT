package com.pwapika.bacaku.data

data class ReadingSession(
    val id: Long = 0,
    val bookId: Long,
    val bookTitle: String = "",
    val startPage: Int = 0,
    val endPage: Int? = null,
    val durationMinutes: Int = 0,
    val pagesRead: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
