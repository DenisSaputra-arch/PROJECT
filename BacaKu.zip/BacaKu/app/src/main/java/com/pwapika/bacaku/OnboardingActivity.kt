package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.databinding.ActivityOnboardingBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private var currentStep = 0

    private val titles = listOf(
        "Lacak progress baca, \u003cem\u003esatu hari\u003c/em\u003e.",
        "Catat setiap halaman, \u003cem\u003etanpa ribet.\u003c/em\u003e",
        "Capai target tahunan, \u003cem\u003eterus berkembang.\u003c/em\u003e"
    )

    private val descriptions = listOf(
        "Pantau buku yang sedang dibaca, target harian, dan streak membaca otomatis.",
        "Geser slider progress di detail buku \u2014 streak harian otomatis berjalan saat kamu update.",
        "Tetapkan target tahunan, kumpulkan lencana, dan lihat statistik bacaan kamu tumbuh."
    )

    private val images = listOf(
        R.drawable.ic_logo,
        R.drawable.ic_book_open,
        R.drawable.ic_award
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = SharedPrefHelper(this)

        updateUI()

        binding.btnNext.setOnClickListener {
            if (currentStep < 2) {
                currentStep++
                updateUI()
            } else {
                prefs.setOnboardingDone()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }

        binding.tvSkip.setOnClickListener {
            prefs.setOnboardingDone()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun updateUI() {
        binding.tvObTitle.text = titles[currentStep]
        binding.tvObDesc.text = descriptions[currentStep]

        // Update dots
        binding.dot1.setBackgroundResource(if (currentStep == 0) R.drawable.bg_dot_active else R.drawable.bg_dot_inactive)
        binding.dot2.setBackgroundResource(if (currentStep == 1) R.drawable.bg_dot_active else R.drawable.bg_dot_inactive)
        binding.dot3.setBackgroundResource(if (currentStep == 2) R.drawable.bg_dot_active else R.drawable.bg_dot_inactive)

        if (currentStep == 2) {
            binding.btnNext.text = "Mulai"
        } else {
            binding.btnNext.text = getString(R.string.lanjut)
        }
    }
}
