package com.pwapika.bacaku

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.databinding.ActivityTentangBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class TentangActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTentangBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTentangBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        val prefs = SharedPrefHelper(this)
        val userName = prefs.getUserName()
        val initials = userName.split(" ").map { it.first() }.joinToString("").uppercase().take(2)

        binding.tvDevName.text = userName
        binding.tvDevInitials.text = initials

        binding.rowWebsite.setOnClickListener {
            Toast.makeText(this, "Website: bacaku.app", Toast.LENGTH_SHORT).show()
        }

        binding.rowInstagram.setOnClickListener {
            Toast.makeText(this, "Instagram: @bacaku.app", Toast.LENGTH_SHORT).show()
        }

        binding.rowEmail.setOnClickListener {
            Toast.makeText(this, "Email: halo@bacaku.app", Toast.LENGTH_SHORT).show()
        }

        binding.rowLicense.setOnClickListener {
            Toast.makeText(this, "MIT License", Toast.LENGTH_SHORT).show()
        }
    }
}
