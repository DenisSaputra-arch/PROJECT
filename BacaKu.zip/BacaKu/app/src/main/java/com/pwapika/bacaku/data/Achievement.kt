package com.pwapika.bacaku.data

data class Achievement(
    val id: Long = 0,
    val title: String,
    val description: String,
    val icon: String = "star",
    val unlocked: Boolean = false,
    val unlockedAt: Long? = null,
    val progressTarget: Int = 1,
    val currentProgress: Int = 0
) {
    val progressPercent: Int
        get() = if (progressTarget > 0) ((currentProgress.toFloat() / progressTarget) * 100).toInt() else 0
}
