package com.pwapika.bacaku.data

data class User(
    val id: Long = 0,
    val name: String,
    val email: String,
    val password: String = "",
    val yearlyTarget: Int = 25,
    val reminderTime: String = "20:00",
    val reminderEnabled: Boolean = true,
    val darkMode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
