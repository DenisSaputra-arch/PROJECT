package com.pwapika.bacaku.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pwapika.bacaku.R
import com.pwapika.bacaku.data.Achievement

class AchievementAdapter(
    private val achievements: List<Achievement>,
    private val isUnlocked: Boolean
) : RecyclerView.Adapter<AchievementAdapter.AchViewHolder>() {

    class AchViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flMedal: FrameLayout = itemView.findViewById(R.id.flMedal)
        val ivMedalIcon: ImageView = itemView.findViewById(R.id.ivMedalIcon)
        val tvTitle: TextView = itemView.findViewById(R.id.tvAchTitle)
        val tvDesc: TextView = itemView.findViewById(R.id.tvAchDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AchViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_achievement, parent, false)
        return AchViewHolder(view)
    }

    override fun onBindViewHolder(holder: AchViewHolder, position: Int) {
        val ach = achievements[position]
        holder.tvTitle.text = ach.title
        holder.tvDesc.text = ach.description

        if (isUnlocked) {
            holder.flMedal.setBackgroundResource(R.drawable.bg_medal)
            holder.ivMedalIcon.setImageResource(when (ach.icon) {
                "fire" -> R.drawable.ic_fire
                "globe" -> R.drawable.ic_globe
                "circle" -> R.drawable.ic_award
                else -> R.drawable.ic_star
            })
        } else {
            holder.flMedal.setBackgroundResource(R.drawable.bg_medal_locked)
            holder.ivMedalIcon.setImageResource(R.drawable.ic_lock)
            holder.tvDesc.text = "${ach.currentProgress}/${ach.progressTarget} ${ach.description.lowercase()}"
        }
    }

    override fun getItemCount(): Int = achievements.size
}
