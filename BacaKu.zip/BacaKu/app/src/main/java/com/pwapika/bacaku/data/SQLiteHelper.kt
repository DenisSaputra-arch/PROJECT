package com.pwapika.bacaku.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLiteHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "BacaKu.db"
        private const val DATABASE_VERSION = 1

        // Table Books
        const val TABLE_BOOKS = "books"
        const val COL_BOOK_ID = "id"
        const val COL_BOOK_TITLE = "title"
        const val COL_BOOK_AUTHOR = "author"
        const val COL_BOOK_CATEGORY = "category"
        const val COL_BOOK_TOTAL_PAGES = "total_pages"
        const val COL_BOOK_CURRENT_PAGE = "current_page"
        const val COL_BOOK_STATUS = "status"
        const val COL_BOOK_NOTES = "notes"
        const val COL_BOOK_COVER_COLOR = "cover_color"
        const val COL_BOOK_RATING = "rating"
        const val COL_BOOK_CREATED = "created_at"
        const val COL_BOOK_UPDATED = "updated_at"

        // Table Quotes & Notes
        const val TABLE_QUOTES = "quotes"
        const val COL_QUOTE_ID = "id"
        const val COL_QUOTE_BOOK_ID = "book_id"
        const val COL_QUOTE_BOOK_TITLE = "book_title"
        const val COL_QUOTE_BOOK_AUTHOR = "book_author"
        const val COL_QUOTE_TYPE = "type"
        const val COL_QUOTE_CONTENT = "content"
        const val COL_QUOTE_PAGE = "page_number"
        const val COL_QUOTE_TAGS = "tags"
        const val COL_QUOTE_CREATED = "created_at"

        // Table Achievements
        const val TABLE_ACHIEVEMENTS = "achievements"
        const val COL_ACH_ID = "id"
        const val COL_ACH_TITLE = "title"
        const val COL_ACH_DESC = "description"
        const val COL_ACH_ICON = "icon"
        const val COL_ACH_UNLOCKED = "unlocked"
        const val COL_ACH_UNLOCKED_AT = "unlocked_at"
        const val COL_ACH_TARGET = "progress_target"
        const val COL_ACH_CURRENT = "current_progress"

        // Table Users
        const val TABLE_USERS = "users"
        const val COL_USER_ID = "id"
        const val COL_USER_NAME = "name"
        const val COL_USER_EMAIL = "email"
        const val COL_USER_PASSWORD = "password"
        const val COL_USER_TARGET = "yearly_target"
        const val COL_USER_REMINDER = "reminder_time"
        const val COL_USER_REMINDER_ENABLED = "reminder_enabled"
        const val COL_USER_DARK_MODE = "dark_mode"
        const val COL_USER_CREATED = "created_at"

        // Table Notifications
        const val TABLE_NOTIFICATIONS = "notifications"
        const val COL_NOTIF_ID = "id"
        const val COL_NOTIF_TITLE = "title"
        const val COL_NOTIF_MESSAGE = "message"
        const val COL_NOTIF_TYPE = "type"
        const val COL_NOTIF_READ = "read_status"
        const val COL_NOTIF_CREATED = "created_at"

        // Table Reading Sessions
        const val TABLE_SESSIONS = "reading_sessions"
        const val COL_SESS_ID = "id"
        const val COL_SESS_BOOK_ID = "book_id"
        const val COL_SESS_BOOK_TITLE = "book_title"
        const val COL_SESS_START_PAGE = "start_page"
        const val COL_SESS_END_PAGE = "end_page"
        const val COL_SESS_DURATION = "duration_minutes"
        const val COL_SESS_PAGES = "pages_read"
        const val COL_SESS_CREATED = "created_at"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Books table
        db.execSQL("""
            CREATE TABLE $TABLE_BOOKS (
                $COL_BOOK_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_BOOK_TITLE TEXT NOT NULL,
                $COL_BOOK_AUTHOR TEXT NOT NULL,
                $COL_BOOK_CATEGORY TEXT DEFAULT 'Self-Help',
                $COL_BOOK_TOTAL_PAGES INTEGER DEFAULT 0,
                $COL_BOOK_CURRENT_PAGE INTEGER DEFAULT 0,
                $COL_BOOK_STATUS TEXT DEFAULT 'Sedang',
                $COL_BOOK_NOTES TEXT,
                $COL_BOOK_COVER_COLOR TEXT DEFAULT 'brown',
                $COL_BOOK_RATING REAL DEFAULT 0,
                $COL_BOOK_CREATED INTEGER,
                $COL_BOOK_UPDATED INTEGER
            )
        """.trimIndent())

        // Quotes table
        db.execSQL("""
            CREATE TABLE $TABLE_QUOTES (
                $COL_QUOTE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_QUOTE_BOOK_ID INTEGER,
                $COL_QUOTE_BOOK_TITLE TEXT,
                $COL_QUOTE_BOOK_AUTHOR TEXT,
                $COL_QUOTE_TYPE TEXT DEFAULT 'kutipan',
                $COL_QUOTE_CONTENT TEXT NOT NULL,
                $COL_QUOTE_PAGE INTEGER DEFAULT 0,
                $COL_QUOTE_TAGS TEXT,
                $COL_QUOTE_CREATED INTEGER
            )
        """.trimIndent())

        // Achievements table
        db.execSQL("""
            CREATE TABLE $TABLE_ACHIEVEMENTS (
                $COL_ACH_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ACH_TITLE TEXT NOT NULL,
                $COL_ACH_DESC TEXT,
                $COL_ACH_ICON TEXT,
                $COL_ACH_UNLOCKED INTEGER DEFAULT 0,
                $COL_ACH_UNLOCKED_AT INTEGER,
                $COL_ACH_TARGET INTEGER DEFAULT 1,
                $COL_ACH_CURRENT INTEGER DEFAULT 0
            )
        """.trimIndent())

        // Users table
        db.execSQL("""
            CREATE TABLE $TABLE_USERS (
                $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USER_NAME TEXT NOT NULL,
                $COL_USER_EMAIL TEXT UNIQUE NOT NULL,
                $COL_USER_PASSWORD TEXT NOT NULL,
                $COL_USER_TARGET INTEGER DEFAULT 25,
                $COL_USER_REMINDER TEXT DEFAULT '20:00',
                $COL_USER_REMINDER_ENABLED INTEGER DEFAULT 1,
                $COL_USER_DARK_MODE INTEGER DEFAULT 0,
                $COL_USER_CREATED INTEGER
            )
        """.trimIndent())

        // Notifications table
        db.execSQL("""
            CREATE TABLE $TABLE_NOTIFICATIONS (
                $COL_NOTIF_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NOTIF_TITLE TEXT NOT NULL,
                $COL_NOTIF_MESSAGE TEXT,
                $COL_NOTIF_TYPE TEXT DEFAULT 'general',
                $COL_NOTIF_READ INTEGER DEFAULT 0,
                $COL_NOTIF_CREATED INTEGER
            )
        """.trimIndent())

        // Reading sessions table
        db.execSQL("""
            CREATE TABLE $TABLE_SESSIONS (
                $COL_SESS_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_SESS_BOOK_ID INTEGER,
                $COL_SESS_BOOK_TITLE TEXT,
                $COL_SESS_START_PAGE INTEGER DEFAULT 0,
                $COL_SESS_END_PAGE INTEGER,
                $COL_SESS_DURATION INTEGER DEFAULT 0,
                $COL_SESS_PAGES INTEGER DEFAULT 0,
                $COL_SESS_CREATED INTEGER
            )
        """.trimIndent())

        // Insert default achievements
        insertDefaultAchievements(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BOOKS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_QUOTES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ACHIEVEMENTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NOTIFICATIONS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_SESSIONS")
        onCreate(db)
    }

    private fun insertDefaultAchievements(db: SQLiteDatabase) {
        val achievements = listOf(
            Triple("Buku Pertama", "Selesai 1 buku", "star"),
            Triple("Streak 7 Hari", "7 hari beruntun membaca", "fire"),
            Triple("1.000 Halaman", "Tercapai!", "circle"),
            Triple("Streak 30", "30 hari beruntun", "fire"),
            Triple("25 Buku", "Selesai 25 buku", "star"),
            Triple("5 Genre", "Baca 5 genre berbeda", "globe")
        )
        val targets = listOf(1, 7, 1000, 30, 25, 5)
        achievements.forEachIndexed { index, (title, desc, icon) ->
            val values = ContentValues().apply {
                put(COL_ACH_TITLE, title)
                put(COL_ACH_DESC, desc)
                put(COL_ACH_ICON, icon)
                put(COL_ACH_UNLOCKED, 0)
                put(COL_ACH_TARGET, targets[index])
                put(COL_ACH_CURRENT, 0)
            }
            db.insert(TABLE_ACHIEVEMENTS, null, values)
        }
    }

    // ==================== BOOK CRUD ====================

    fun addBook(book: Book): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_BOOK_TITLE, book.title)
            put(COL_BOOK_AUTHOR, book.author)
            put(COL_BOOK_CATEGORY, book.category)
            put(COL_BOOK_TOTAL_PAGES, book.totalPages)
            put(COL_BOOK_CURRENT_PAGE, book.currentPage)
            put(COL_BOOK_STATUS, book.status)
            put(COL_BOOK_NOTES, book.notes)
            put(COL_BOOK_COVER_COLOR, book.coverColor)
            put(COL_BOOK_RATING, book.rating)
            put(COL_BOOK_CREATED, book.createdAt)
            put(COL_BOOK_UPDATED, book.updatedAt)
        }
        return db.insert(TABLE_BOOKS, null, values)
    }

    fun updateBook(book: Book): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_BOOK_TITLE, book.title)
            put(COL_BOOK_AUTHOR, book.author)
            put(COL_BOOK_CATEGORY, book.category)
            put(COL_BOOK_TOTAL_PAGES, book.totalPages)
            put(COL_BOOK_CURRENT_PAGE, book.currentPage)
            put(COL_BOOK_STATUS, book.status)
            put(COL_BOOK_NOTES, book.notes)
            put(COL_BOOK_COVER_COLOR, book.coverColor)
            put(COL_BOOK_RATING, book.rating)
            put(COL_BOOK_UPDATED, System.currentTimeMillis())
        }
        return db.update(TABLE_BOOKS, values, "$COL_BOOK_ID = ?", arrayOf(book.id.toString()))
    }

    fun deleteBook(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_BOOKS, "$COL_BOOK_ID = ?", arrayOf(id.toString()))
    }

    fun getAllBooks(): List<Book> {
        val books = mutableListOf<Book>()
        val db = readableDatabase
        val cursor = db.query(TABLE_BOOKS, null, null, null, null, null, "$COL_BOOK_UPDATED DESC")
        with(cursor) {
            while (moveToNext()) {
                books.add(parseBookCursor(this))
            }
            close()
        }
        return books
    }

    fun getBooksByStatus(status: String): List<Book> {
        val books = mutableListOf<Book>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BOOKS, null, "$COL_BOOK_STATUS = ?",
            arrayOf(status), null, null, "$COL_BOOK_UPDATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                books.add(parseBookCursor(this))
            }
            close()
        }
        return books
    }

    fun getBookById(id: Long): Book? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BOOKS, null, "$COL_BOOK_ID = ?",
            arrayOf(id.toString()), null, null, null
        )
        return if (cursor.moveToFirst()) {
            val book = parseBookCursor(cursor)
            cursor.close()
            book
        } else {
            cursor.close()
            null
        }
    }

    fun searchBooks(query: String): List<Book> {
        val books = mutableListOf<Book>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BOOKS, null,
            "$COL_BOOK_TITLE LIKE ? OR $COL_BOOK_AUTHOR LIKE ?",
            arrayOf("%$query%", "%$query%"),
            null, null, "$COL_BOOK_UPDATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                books.add(parseBookCursor(this))
            }
            close()
        }
        return books
    }

    fun getBooksByCategory(category: String): List<Book> {
        val books = mutableListOf<Book>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BOOKS, null, "$COL_BOOK_CATEGORY = ?",
            arrayOf(category), null, null, "$COL_BOOK_UPDATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                books.add(parseBookCursor(this))
            }
            close()
        }
        return books
    }

    fun getFinishedBookCount(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_BOOKS WHERE $COL_BOOK_STATUS = 'Selesai'", null
        )
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return count
    }

    fun getReadingBookCount(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_BOOKS WHERE $COL_BOOK_STATUS = 'Sedang'", null
        )
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return count
    }

    fun getTotalPagesRead(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT SUM($COL_BOOK_CURRENT_PAGE) FROM $TABLE_BOOKS", null
        )
        val total = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return total
    }

    fun getGenreDistribution(): Map<String, Int> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COL_BOOK_CATEGORY, COUNT(*) FROM $TABLE_BOOKS WHERE $COL_BOOK_STATUS = 'Selesai' GROUP BY $COL_BOOK_CATEGORY",
            null
        )
        val result = mutableMapOf<String, Int>()
        with(cursor) {
            while (moveToNext()) {
                result[getString(0)] = getInt(1)
            }
            close()
        }
        return result
    }

    private fun parseBookCursor(cursor: android.database.Cursor): Book {
        return Book(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_BOOK_ID)),
            title = cursor.getString(cursor.getColumnIndexOrThrow(COL_BOOK_TITLE)),
            author = cursor.getString(cursor.getColumnIndexOrThrow(COL_BOOK_AUTHOR)),
            category = cursor.getString(cursor.getColumnIndexOrThrow(COL_BOOK_CATEGORY)),
            totalPages = cursor.getInt(cursor.getColumnIndexOrThrow(COL_BOOK_TOTAL_PAGES)),
            currentPage = cursor.getInt(cursor.getColumnIndexOrThrow(COL_BOOK_CURRENT_PAGE)),
            status = cursor.getString(cursor.getColumnIndexOrThrow(COL_BOOK_STATUS)),
            notes = cursor.getString(cursor.getColumnIndexOrThrow(COL_BOOK_NOTES)) ?: "",
            coverColor = cursor.getString(cursor.getColumnIndexOrThrow(COL_BOOK_COVER_COLOR)),
            rating = cursor.getFloat(cursor.getColumnIndexOrThrow(COL_BOOK_RATING)),
            createdAt = cursor.getLong(cursor.getColumnIndexOrThrow(COL_BOOK_CREATED)),
            updatedAt = cursor.getLong(cursor.getColumnIndexOrThrow(COL_BOOK_UPDATED))
        )
    }

    // ==================== QUOTES CRUD ====================

    fun addQuote(quote: Quote): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_QUOTE_BOOK_ID, quote.bookId)
            put(COL_QUOTE_BOOK_TITLE, quote.bookTitle)
            put(COL_QUOTE_BOOK_AUTHOR, quote.bookAuthor)
            put(COL_QUOTE_TYPE, quote.type)
            put(COL_QUOTE_CONTENT, quote.content)
            put(COL_QUOTE_PAGE, quote.pageNumber)
            put(COL_QUOTE_TAGS, quote.tags)
            put(COL_QUOTE_CREATED, quote.createdAt)
        }
        return db.insert(TABLE_QUOTES, null, values)
    }

    fun deleteQuote(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_QUOTES, "$COL_QUOTE_ID = ?", arrayOf(id.toString()))
    }

    fun getAllQuotes(): List<Quote> {
        val quotes = mutableListOf<Quote>()
        val db = readableDatabase
        val cursor = db.query(TABLE_QUOTES, null, null, null, null, null, "$COL_QUOTE_CREATED DESC")
        with(cursor) {
            while (moveToNext()) {
                quotes.add(parseQuoteCursor(this))
            }
            close()
        }
        return quotes
    }

    fun getQuotesByType(type: String): List<Quote> {
        val quotes = mutableListOf<Quote>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_QUOTES, null, "$COL_QUOTE_TYPE = ?",
            arrayOf(type), null, null, "$COL_QUOTE_CREATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                quotes.add(parseQuoteCursor(this))
            }
            close()
        }
        return quotes
    }

    fun getQuotesByBookId(bookId: Long): List<Quote> {
        val quotes = mutableListOf<Quote>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_QUOTES, null, "$COL_QUOTE_BOOK_ID = ?",
            arrayOf(bookId.toString()), null, null, "$COL_QUOTE_CREATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                quotes.add(parseQuoteCursor(this))
            }
            close()
        }
        return quotes
    }

    fun searchQuotes(query: String): List<Quote> {
        val quotes = mutableListOf<Quote>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_QUOTES, null,
            "$COL_QUOTE_CONTENT LIKE ? OR $COL_QUOTE_TAGS LIKE ?",
            arrayOf("%$query%", "%$query%"),
            null, null, "$COL_QUOTE_CREATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                quotes.add(parseQuoteCursor(this))
            }
            close()
        }
        return quotes
    }

    private fun parseQuoteCursor(cursor: android.database.Cursor): Quote {
        return Quote(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_QUOTE_ID)),
            bookId = cursor.getLong(cursor.getColumnIndexOrThrow(COL_QUOTE_BOOK_ID)),
            bookTitle = cursor.getString(cursor.getColumnIndexOrThrow(COL_QUOTE_BOOK_TITLE)) ?: "",
            bookAuthor = cursor.getString(cursor.getColumnIndexOrThrow(COL_QUOTE_BOOK_AUTHOR)) ?: "",
            type = cursor.getString(cursor.getColumnIndexOrThrow(COL_QUOTE_TYPE)),
            content = cursor.getString(cursor.getColumnIndexOrThrow(COL_QUOTE_CONTENT)),
            pageNumber = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QUOTE_PAGE)),
            tags = cursor.getString(cursor.getColumnIndexOrThrow(COL_QUOTE_TAGS)) ?: "",
            createdAt = cursor.getLong(cursor.getColumnIndexOrThrow(COL_QUOTE_CREATED))
        )
    }

    // ==================== ACHIEVEMENTS ====================

    fun getAllAchievements(): List<Achievement> {
        val achievements = mutableListOf<Achievement>()
        val db = readableDatabase
        val cursor = db.query(TABLE_ACHIEVEMENTS, null, null, null, null, null, COL_ACH_ID)
        with(cursor) {
            while (moveToNext()) {
                achievements.add(parseAchCursor(this))
            }
            close()
        }
        return achievements
    }

    fun getUnlockedAchievements(): List<Achievement> {
        val achievements = mutableListOf<Achievement>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ACHIEVEMENTS, null, "$COL_ACH_UNLOCKED = ?",
            arrayOf("1"), null, null, COL_ACH_ID
        )
        with(cursor) {
            while (moveToNext()) {
                achievements.add(parseAchCursor(this))
            }
            close()
        }
        return achievements
    }

    fun getLockedAchievements(): List<Achievement> {
        val achievements = mutableListOf<Achievement>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ACHIEVEMENTS, null, "$COL_ACH_UNLOCKED = ?",
            arrayOf("0"), null, null, COL_ACH_ID
        )
        with(cursor) {
            while (moveToNext()) {
                achievements.add(parseAchCursor(this))
            }
            close()
        }
        return achievements
    }

    fun updateAchievementProgress(id: Long, current: Int): Int {
        val db = writableDatabase
        val ach = getAchievementById(id) ?: return 0
        val unlocked = if (current >= ach.progressTarget) 1 else 0
        val values = ContentValues().apply {
            put(COL_ACH_CURRENT, current)
            put(COL_ACH_UNLOCKED, unlocked)
            if (unlocked == 1 && ach.unlockedAt == null) {
                put(COL_ACH_UNLOCKED_AT, System.currentTimeMillis())
            }
        }
        return db.update(TABLE_ACHIEVEMENTS, values, "$COL_ACH_ID = ?", arrayOf(id.toString()))
    }

    fun getAchievementById(id: Long): Achievement? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ACHIEVEMENTS, null, "$COL_ACH_ID = ?",
            arrayOf(id.toString()), null, null, null
        )
        return if (cursor.moveToFirst()) {
            val ach = parseAchCursor(cursor)
            cursor.close()
            ach
        } else {
            cursor.close()
            null
        }
    }

    private fun parseAchCursor(cursor: android.database.Cursor): Achievement {
        return Achievement(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ACH_ID)),
            title = cursor.getString(cursor.getColumnIndexOrThrow(COL_ACH_TITLE)),
            description = cursor.getString(cursor.getColumnIndexOrThrow(COL_ACH_DESC)) ?: "",
            icon = cursor.getString(cursor.getColumnIndexOrThrow(COL_ACH_ICON)) ?: "star",
            unlocked = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACH_UNLOCKED)) == 1,
            unlockedAt = cursor.getLongOrNull(cursor.getColumnIndexOrThrow(COL_ACH_UNLOCKED_AT)),
            progressTarget = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACH_TARGET)),
            currentProgress = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACH_CURRENT))
        )
    }

    // ==================== USERS ====================

    fun registerUser(user: User): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_USER_NAME, user.name)
            put(COL_USER_EMAIL, user.email)
            put(COL_USER_PASSWORD, user.password)
            put(COL_USER_TARGET, user.yearlyTarget)
            put(COL_USER_REMINDER, user.reminderTime)
            put(COL_USER_REMINDER_ENABLED, if (user.reminderEnabled) 1 else 0)
            put(COL_USER_DARK_MODE, if (user.darkMode) 1 else 0)
            put(COL_USER_CREATED, user.createdAt)
        }
        return db.insert(TABLE_USERS, null, values)
    }

    fun loginUser(email: String, password: String): User? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS, null,
            "$COL_USER_EMAIL = ? AND $COL_USER_PASSWORD = ?",
            arrayOf(email, password), null, null, null
        )
        return if (cursor.moveToFirst()) {
            val user = parseUserCursor(cursor)
            cursor.close()
            user
        } else {
            cursor.close()
            null
        }
    }

    fun getUserById(id: Long): User? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS, null, "$COL_USER_ID = ?",
            arrayOf(id.toString()), null, null, null
        )
        return if (cursor.moveToFirst()) {
            val user = parseUserCursor(cursor)
            cursor.close()
            user
        } else {
            cursor.close()
            null
        }
    }

    fun getUserByEmail(email: String): User? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS, null, "$COL_USER_EMAIL = ?",
            arrayOf(email), null, null, null
        )
        return if (cursor.moveToFirst()) {
            val user = parseUserCursor(cursor)
            cursor.close()
            user
        } else {
            cursor.close()
            null
        }
    }

    fun updateUser(user: User): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_USER_NAME, user.name)
            put(COL_USER_EMAIL, user.email)
            put(COL_USER_PASSWORD, user.password)
            put(COL_USER_TARGET, user.yearlyTarget)
            put(COL_USER_REMINDER, user.reminderTime)
            put(COL_USER_REMINDER_ENABLED, if (user.reminderEnabled) 1 else 0)
            put(COL_USER_DARK_MODE, if (user.darkMode) 1 else 0)
        }
        return db.update(TABLE_USERS, values, "$COL_USER_ID = ?", arrayOf(user.id.toString()))
    }

    fun updateUserTarget(userId: Long, target: Int): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_USER_TARGET, target)
        }
        return db.update(TABLE_USERS, values, "$COL_USER_ID = ?", arrayOf(userId.toString()))
    }

    private fun parseUserCursor(cursor: android.database.Cursor): User {
        return User(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID)),
            name = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)),
            email = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL)),
            password = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD)),
            yearlyTarget = cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_TARGET)),
            reminderTime = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_REMINDER)),
            reminderEnabled = cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_REMINDER_ENABLED)) == 1,
            darkMode = cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_DARK_MODE)) == 1,
            createdAt = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_CREATED))
        )
    }

    // ==================== NOTIFICATIONS ====================

    fun addNotification(notification: Notification): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NOTIF_TITLE, notification.title)
            put(COL_NOTIF_MESSAGE, notification.message)
            put(COL_NOTIF_TYPE, notification.type)
            put(COL_NOTIF_READ, if (notification.read) 1 else 0)
            put(COL_NOTIF_CREATED, notification.createdAt)
        }
        return db.insert(TABLE_NOTIFICATIONS, null, values)
    }

    fun getAllNotifications(): List<Notification> {
        val notifications = mutableListOf<Notification>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NOTIFICATIONS, null, null, null, null, null,
            "$COL_NOTIF_CREATED DESC"
        )
        with(cursor) {
            while (moveToNext()) {
                notifications.add(parseNotifCursor(this))
            }
            close()
        }
        return notifications
    }

    fun markNotificationRead(id: Long): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NOTIF_READ, 1)
        }
        return db.update(TABLE_NOTIFICATIONS, values, "$COL_NOTIF_ID = ?", arrayOf(id.toString()))
    }

    fun getUnreadNotificationCount(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_NOTIFICATIONS WHERE $COL_NOTIF_READ = 0", null
        )
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return count
    }

    private fun parseNotifCursor(cursor: android.database.Cursor): Notification {
        return Notification(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_NOTIF_ID)),
            title = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOTIF_TITLE)),
            message = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOTIF_MESSAGE)) ?: "",
            type = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOTIF_TYPE)),
            read = cursor.getInt(cursor.getColumnIndexOrThrow(COL_NOTIF_READ)) == 1,
            createdAt = cursor.getLong(cursor.getColumnIndexOrThrow(COL_NOTIF_CREATED))
        )
    }

    // ==================== READING SESSIONS ====================

    fun addSession(session: ReadingSession): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_SESS_BOOK_ID, session.bookId)
            put(COL_SESS_BOOK_TITLE, session.bookTitle)
            put(COL_SESS_START_PAGE, session.startPage)
            put(COL_SESS_END_PAGE, session.endPage)
            put(COL_SESS_DURATION, session.durationMinutes)
            put(COL_SESS_PAGES, session.pagesRead)
            put(COL_SESS_CREATED, session.createdAt)
        }
        return db.insert(TABLE_SESSIONS, null, values)
    }

    fun getTodayReadingMinutes(): Int {
        val db = readableDatabase
        val today = System.currentTimeMillis() - 86400000 // 24 hours ago
        val cursor = db.rawQuery(
            "SELECT SUM($COL_SESS_DURATION) FROM $TABLE_SESSIONS WHERE $COL_SESS_CREATED > ?",
            arrayOf(today.toString())
        )
        val total = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return total
    }

    fun getWeekReadingMinutes(): Int {
        val db = readableDatabase
        val week = System.currentTimeMillis() - 604800000 // 7 days
        val cursor = db.rawQuery(
            "SELECT SUM($COL_SESS_DURATION) FROM $TABLE_SESSIONS WHERE $COL_SESS_CREATED > ?",
            arrayOf(week.toString())
        )
        val total = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return total
    }

    fun getDailyPages(): Map<String, Int> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT date($COL_SESS_CREATED/1000, 'unixepoch', 'localtime') as day, 
                   SUM($COL_SESS_PAGES) 
            FROM $TABLE_SESSIONS 
            GROUP BY day 
            ORDER BY day DESC 
            LIMIT 7
            """.trimIndent(), null
        )
        val result = mutableMapOf<String, Int>()
        with(cursor) {
            while (moveToNext()) {
                result[getString(0)] = getInt(1)
            }
            close()
        }
        return result
    }

    private fun android.database.Cursor.getLongOrNull(columnIndex: Int): Long? {
        return if (isNull(columnIndex)) null else getLong(columnIndex)
    }
}
