package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.pwapika.bacaku.adapter.BookAdapter
import com.pwapika.bacaku.adapter.ShelfAdapter
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityCariBinding

class CariActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCariBinding
    private lateinit var db: SQLiteHelper
    private var selectedCategory = "Semua"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCariBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)

        binding.btnBack.setOnClickListener { finish() }

        // Search
        binding.etSearch.setOnEditorActionListener { _, _, _ ->
            performSearch(binding.etSearch.text.toString())
            true
        }

        binding.searchBar.setOnClickListener {
            binding.etSearch.requestFocus()
        }

        // Category chips
        setupCategoryChips()

        // Load popular books
        loadPopularBooks()
    }

    private fun setupCategoryChips() {
        binding.chipSemua.setOnClickListener { selectCategory("Semua") }
        binding.chipSelfHelp.setOnClickListener { selectCategory("Self-Help") }
        binding.chipFiksi.setOnClickListener { selectCategory("Fiksi") }
        binding.chipBisnis.setOnClickListener { selectCategory("Bisnis") }
        binding.chipSains.setOnClickListener { selectCategory("Sains") }
    }

    private fun selectCategory(category: String) {
        selectedCategory = category
        updateChipUI()
        if (category == "Semua") {
            binding.tvResultsTitle.visibility = View.GONE
            binding.rvSearchResults.visibility = View.GONE
        } else {
            val books = db.getBooksByCategory(category)
            showSearchResults(books, category)
        }
    }

    private fun updateChipUI() {
        binding.chipSemua.setBackgroundResource(if (selectedCategory == "Semua") R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
        binding.chipSemua.setTextColor(if (selectedCategory == "Semua") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.chipSelfHelp.setBackgroundResource(if (selectedCategory == "Self-Help") R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
        binding.chipSelfHelp.setTextColor(if (selectedCategory == "Self-Help") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.chipFiksi.setBackgroundResource(if (selectedCategory == "Fiksi") R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
        binding.chipFiksi.setTextColor(if (selectedCategory == "Fiksi") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.chipBisnis.setBackgroundResource(if (selectedCategory == "Bisnis") R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
        binding.chipBisnis.setTextColor(if (selectedCategory == "Bisnis") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.chipSains.setBackgroundResource(if (selectedCategory == "Sains") R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
        binding.chipSains.setTextColor(if (selectedCategory == "Sains") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))
    }

    private fun performSearch(query: String) {
        if (query.isEmpty()) return
        val books = db.searchBooks(query)
        showSearchResults(books, query)
    }

    private fun showSearchResults(books: List<Book>, query: String) {
        binding.tvResultsTitle.visibility = View.VISIBLE
        binding.tvResultsTitle.text = "Hasil untuk \"$query\""
        binding.rvSearchResults.visibility = View.VISIBLE
        binding.rvSearchResults.layoutManager = LinearLayoutManager(this)
        binding.rvSearchResults.adapter = BookAdapter(books) { book ->
            val intent = Intent(this, DetailBukuActivity::class.java)
            intent.putExtra("book_id", book.id)
            startActivity(intent)
        }
    }

    private fun loadPopularBooks() {
        val popularBooks = listOf(
            Book(id = 4, title = "Laut Bercerita", author = "Leila Chudori", category = "Fiksi", totalPages = 400, coverColor = "rust"),
            Book(id = 5, title = "Sapiens", author = "Y. N. Harari", category = "Sains", totalPages = 450, coverColor = "teal"),
            Book(id = 6, title = "Bumi Manusia", author = "Pramoedya", category = "Fiksi", totalPages = 350, coverColor = "plum")
        )
        binding.rvPopular.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvPopular.adapter = ShelfAdapter(popularBooks) { book ->
            val intent = Intent(this, DetailBukuActivity::class.java)
            intent.putExtra("book_id", book.id)
            startActivity(intent)
        }
    }
}
