package com.pwapika.bacaku

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.pwapika.bacaku.adapter.AchievementAdapter
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityAchievementsBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class AchievementsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAchievementsBinding
    private lateinit var db: SQLiteHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAchievementsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        val prefs = SharedPrefHelper(this)

        binding.btnBack.setOnClickListener { finish() }

        // Stats
        val unlockedCount = db.getUnlockedAchievements().size
        val totalCount = db.getAllAchievements().size
        binding.tvAchProgress.text = "$unlockedCount dari $totalCount lencana"

        // Unlocked
        val unlocked = db.getUnlockedAchievements()
        binding.rvUnlocked.layoutManager = GridLayoutManager(this, 3)
        binding.rvUnlocked.adapter = AchievementAdapter(unlocked, true)

        // Locked
        val locked = db.getLockedAchievements()
        binding.rvLocked.layoutManager = GridLayoutManager(this, 3)
        binding.rvLocked.adapter = AchievementAdapter(locked, false)
    }
}
