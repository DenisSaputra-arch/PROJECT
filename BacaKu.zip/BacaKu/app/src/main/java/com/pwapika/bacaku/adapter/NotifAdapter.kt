package com.pwapika.bacaku.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pwapika.bacaku.R
import com.pwapika.bacaku.data.Notification
import com.pwapika.bacaku.util.DateUtil

class NotifAdapter(
    private val notifications: List<Notification>,
    private val onClick: (Notification) -> Unit
) : RecyclerView.Adapter<NotifAdapter.NotifViewHolder>() {

    class NotifViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flIcon: FrameLayout = itemView.findViewById(R.id.flNotifIcon)
        val ivIcon: ImageView = itemView.findViewById(R.id.ivNotifIcon)
        val tvTitle: TextView = itemView.findViewById(R.id.tvNotifTitle)
        val tvTime: TextView = itemView.findViewById(R.id.tvNotifTime)
        val dotUnread: View = itemView.findViewById(R.id.dotUnread)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotifViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_notification, parent, false)
        return NotifViewHolder(view)
    }

    override fun onBindViewHolder(holder: NotifViewHolder, position: Int) {
        val notif = notifications[position]
        holder.tvTitle.text = notif.title
        holder.tvTime.text = DateUtil.formatTimeAgo(notif.createdAt)
        holder.dotUnread.visibility = if (notif.read) View.GONE else View.VISIBLE

        // Icon based on type
        when (notif.type) {
            "streak" -> {
                holder.flIcon.setBackgroundResource(R.drawable.bg_icon_brand)
                holder.ivIcon.setImageResource(R.drawable.ic_fire)
            }
            "reminder" -> {
                holder.flIcon.setBackgroundResource(R.drawable.bg_icon_sage)
                holder.ivIcon.setImageResource(R.drawable.ic_book_open)
            }
            "achievement" -> {
                holder.flIcon.setBackgroundResource(R.drawable.bg_icon_gold)
                holder.ivIcon.setImageResource(R.drawable.ic_award)
            }
            else -> {
                holder.flIcon.setBackgroundResource(R.drawable.bg_icon_brand)
                holder.ivIcon.setImageResource(R.drawable.ic_bell)
            }
        }

        holder.itemView.setOnClickListener { onClick(notif) }
    }

    override fun getItemCount(): Int = notifications.size
}
