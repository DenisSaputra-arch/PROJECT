package com.pwapika.bacaku.util

import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object DateUtil {

    private val dayFormat = SimpleDateFormat("EEE", Locale("id"))
    private val fullDateFormat = SimpleDateFormat("EEEE, d MMMM", Locale("id"))
    private val timeFormat = SimpleDateFormat("HH:mm", Locale("id"))
    private val shortDateFormat = SimpleDateFormat("d MMM", Locale("id"))

    fun getCurrentDay(): String = dayFormat.format(Date())

    fun getFullDate(): String = fullDateFormat.format(Date())

    fun getCurrentTime(): String = timeFormat.format(Date())

    fun formatShortDate(timestamp: Long): String = shortDateFormat.format(Date(timestamp))

    fun formatTimeAgo(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        return when {
            diff < TimeUnit.MINUTES.toMillis(1) -> "Baru saja"
            diff < TimeUnit.HOURS.toMillis(1) -> "${TimeUnit.MILLISECONDS.toMinutes(diff)} menit lalu"
            diff < TimeUnit.HOURS.toMillis(2) -> "2 jam lalu"
            diff < TimeUnit.DAYS.toMillis(1) -> timeFormat.format(Date(timestamp))
            diff < TimeUnit.DAYS.toMillis(2) -> "Kemarin"
            else -> shortDateFormat.format(Date(timestamp))
        }
    }

    fun formatDuration(minutes: Int): String {
        return when {
            minutes >= 60 -> {
                val h = minutes / 60
                val m = minutes % 60
                "${h}j ${m}m"
            }
            else -> "${minutes}m"
        }
    }

    fun getDaysInMonth(): Int {
        val calendar = Calendar.getInstance()
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun getCurrentMonthName(): String {
        val monthFormat = SimpleDateFormat("MMMM", Locale("id"))
        return monthFormat.format(Date())
    }

    fun getRemainingMonths(): Int {
        val calendar = Calendar.getInstance()
        return 12 - calendar.get(Calendar.MONTH)
    }
}
