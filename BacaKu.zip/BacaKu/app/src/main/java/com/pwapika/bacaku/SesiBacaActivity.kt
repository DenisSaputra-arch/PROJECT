package com.pwapika.bacaku

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.ReadingSession
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivitySesiBacaBinding
import com.pwapika.bacaku.util.DateUtil

class SesiBacaActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySesiBacaBinding
    private lateinit var db: SQLiteHelper
    private var bookId: Long = -1
    private var book: Book? = null

    private var isRunning = true
    private var elapsedSeconds = 0
    private val handler = Handler(Looper.getMainLooper())
    private val startTime = SystemClock.elapsedRealtime()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySesiBacaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        bookId = intent.getLongExtra("book_id", -1)

        if (bookId == -1L) {
            setupDemoMode()
        } else {
            loadBook()
        }

        // Load stats
        val todayMin = db.getTodayReadingMinutes()
        val weekMin = db.getWeekReadingMinutes()
        binding.tvTodayTime.text = DateUtil.formatDuration(todayMin)
        binding.tvWeekTime.text = DateUtil.formatDuration(weekMin)

        binding.btnClose.setOnClickListener { showEndDialog() }

        binding.btnPause.setOnClickListener {
            isRunning = !isRunning
            if (isRunning) {
                binding.btnPause.setImageResource(R.drawable.ic_pause)
                binding.tvPauseLabel.text = "Tap untuk jeda"
            } else {
                binding.btnPause.setImageResource(R.drawable.ic_play)
                binding.tvPauseLabel.text = "Tap untuk lanjut"
            }
        }

        binding.btnFinish.setOnClickListener {
            saveSession()
        }

        startTimer()
    }

    private fun startTimer() {
        handler.post(object : Runnable {
            override fun run() {
                if (isRunning) {
                    elapsedSeconds++
                    updateTimerDisplay()
                    updateEstPages()
                }
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun updateTimerDisplay() {
        val min = elapsedSeconds / 60
        val sec = elapsedSeconds % 60
        binding.tvTimer.text = String.format("%02d:%02d", min, sec)
    }

    private fun updateEstPages() {
        // Estimate ~2 minutes per page
        val pages = elapsedSeconds / 120
        binding.tvEstPages.text = "\u2248 $pages halaman terbaca"
    }

    private fun setupDemoMode() {
        binding.tvBookTitle.text = "Atomic Habits"
        binding.tvStartPage.text = "Mulai dari hal. 195"
        binding.tvTodayTime.text = "1j 12m"
        binding.tvWeekTime.text = "6j 40m"
    }

    private fun loadBook() {
        book = db.getBookById(bookId)
        book?.let {
            binding.tvBookTitle.text = it.title
            binding.tvStartPage.text = "Mulai dari hal. ${it.currentPage}"
        }
    }

    private fun saveSession() {
        val pages = elapsedSeconds / 120
        val durationMin = elapsedSeconds / 60

        book?.let {
            val session = ReadingSession(
                bookId = it.id,
                bookTitle = it.title,
                startPage = it.currentPage,
                pagesRead = pages,
                durationMinutes = durationMin
            )
            db.addSession(session)

            // Update book progress
            val updated = it.copy(currentPage = it.currentPage + pages)
            db.updateBook(updated)
        }

        Toast.makeText(this, "Sesi tersimpan! $pages halaman dibaca", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun showEndDialog() {
        AlertDialog.Builder(this)
            .setTitle("Akhiri Sesi?")
            .setMessage("Progress sesi ini tidak akan tersimpan.")
            .setPositiveButton("Akhiri") { _, _ -> finish() }
            .setNegativeButton("Lanjut", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
