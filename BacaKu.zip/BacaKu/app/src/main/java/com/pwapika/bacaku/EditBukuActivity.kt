package com.pwapika.bacaku

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityTambahBukuBinding

class EditBukuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTambahBukuBinding
    private lateinit var db: SQLiteHelper
    private var bookId: Long = -1
    private var selectedStatus = "Sedang"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTambahBukuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        bookId = intent.getLongExtra("book_id", -1)

        binding.tvTitle.text = "Edit Buku"
        binding.btnSave.text = "Update Koleksi"

        binding.btnBack.setOnClickListener { finish() }
        setupStatusButtons()
        loadBook()

        binding.btnSave.setOnClickListener { updateBook() }
    }

    private fun setupStatusButtons() {
        binding.btnMauDibaca.setOnClickListener {
            selectedStatus = "Mau Dibaca"
            updateStatusUI()
        }
        binding.btnSedang.setOnClickListener {
            selectedStatus = "Sedang"
            updateStatusUI()
        }
        binding.btnSelesai.setOnClickListener {
            selectedStatus = "Selesai"
            updateStatusUI()
        }
    }

    private fun updateStatusUI() {
        binding.btnMauDibaca.setBackgroundResource(if (selectedStatus == "Mau Dibaca") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnMauDibaca.setTextColor(if (selectedStatus == "Mau Dibaca") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.btnSedang.setBackgroundResource(if (selectedStatus == "Sedang") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnSedang.setTextColor(if (selectedStatus == "Sedang") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.btnSelesai.setBackgroundResource(if (selectedStatus == "Selesai") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnSelesai.setTextColor(if (selectedStatus == "Selesai") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))
    }

    private fun loadBook() {
        val book = db.getBookById(bookId) ?: return
        binding.etTitle.setText(book.title)
        binding.etAuthor.setText(book.author)
        binding.etCategory.setText(book.category)
        binding.etTotalPages.setText(book.totalPages.toString())
        binding.etNotes.setText(book.notes)
        selectedStatus = book.status
        updateStatusUI()
    }

    private fun updateBook() {
        val title = binding.etTitle.text.toString().trim()
        val author = binding.etAuthor.text.toString().trim()
        val category = binding.etCategory.text.toString().trim().ifEmpty { "Self-Help" }
        val totalPages = binding.etTotalPages.text.toString().toIntOrNull() ?: 0
        val notes = binding.etNotes.text.toString().trim()

        if (title.isEmpty() || author.isEmpty()) {
            Toast.makeText(this, "Judul dan penulis wajib diisi", Toast.LENGTH_SHORT).show()
            return
        }

        val book = Book(
            id = bookId,
            title = title,
            author = author,
            category = category,
            totalPages = totalPages,
            status = selectedStatus,
            notes = notes,
            coverColor = "brown",
            updatedAt = System.currentTimeMillis()
        )

        db.updateBook(book)
        Toast.makeText(this, "Buku berhasil diupdate!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
