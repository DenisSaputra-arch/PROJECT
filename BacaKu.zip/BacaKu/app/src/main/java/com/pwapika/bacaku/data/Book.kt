package com.pwapika.bacaku.data

data class Book(
    val id: Long = 0,
    val title: String,
    val author: String,
    val category: String,
    val totalPages: Int,
    val currentPage: Int = 0,
    val status: String = "Sedang", // "Mau Dibaca", "Sedang", "Selesai"
    val notes: String = "",
    val coverColor: String = "brown", // brown, sage, navy, plum, mustard, rust, teal, ink
    val rating: Float = 0f,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val progressPercent: Int
        get() = if (totalPages > 0) ((currentPage.toFloat() / totalPages) * 100).toInt() else 0

    val isFinished: Boolean
        get() = status == "Selesai"
}
