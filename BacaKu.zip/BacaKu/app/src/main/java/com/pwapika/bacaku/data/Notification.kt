package com.pwapika.bacaku.data

data class Notification(
    val id: Long = 0,
    val title: String,
    val message: String,
    val type: String = "general", // streak, reminder, achievement, general
    val read: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
