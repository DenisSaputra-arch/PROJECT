package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.data.User
import com.pwapika.bacaku.databinding.ActivityRegisterBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var db: SQLiteHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnRegister.setOnClickListener {
            val name = binding.etRegName.text.toString().trim()
            val email = binding.etRegEmail.text.toString().trim()
            val password = binding.etRegPassword.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 8) {
                Toast.makeText(this, "Password minimal 8 karakter", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if email exists
            if (db.getUserByEmail(email) != null) {
                Toast.makeText(this, "Email sudah terdaftar", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val user = User(name = name, email = email, password = password)
            val id = db.registerUser(user)

            if (id > 0) {
                Toast.makeText(this, "Akun berhasil dibuat! Silakan masuk.", Toast.LENGTH_SHORT).show()
                val prefs = SharedPrefHelper(this)
                prefs.setLoggedIn(id, name, email)
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Gagal membuat akun", Toast.LENGTH_SHORT).show()
            }
        }

        binding.tvGoLogin.setOnClickListener {
            finish()
        }
    }
}
