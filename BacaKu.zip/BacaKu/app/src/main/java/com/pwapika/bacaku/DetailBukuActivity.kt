package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.data.Book
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityDetailBukuBinding

class DetailBukuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBukuBinding
    private lateinit var db: SQLiteHelper
    private var bookId: Long = -1
    private var book: Book? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBukuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)
        bookId = intent.getLongExtra("book_id", -1)

        if (bookId == -1L) {
            // Demo mode - show sample data
            showDemoData()
        } else {
            loadBook()
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnMore.setOnClickListener { showOptionsMenu() }

        // SeekBar
        binding.seekBarProgress.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                book?.let {
                    val updated = it.copy(currentPage = progress)
                    book = updated
                    updateUI(updated)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                book?.let { db.updateBook(it) }
                Toast.makeText(this@DetailBukuActivity, "Progress diupdate", Toast.LENGTH_SHORT).show()
            }
        })

        // Status buttons
        binding.btnMauDibaca.setOnClickListener { updateStatus("Mau Dibaca") }
        binding.btnSedang.setOnClickListener { updateStatus("Sedang") }
        binding.btnSelesai.setOnClickListener { updateStatus("Selesai") }
    }

    private fun showDemoData() {
        val demoBook = Book(
            id = 1,
            title = "Atomic Habits",
            author = "James Clear",
            category = "Self-Improvement",
            totalPages = 300,
            currentPage = 195,
            status = "Sedang",
            notes = "Buku ini sangat membantu memahami bagaimana kebiasaan kecil dapat menghasilkan perubahan besar.",
            coverColor = "brown",
            rating = 4.8f
        )
        book = demoBook
        updateUI(demoBook)
    }

    private fun loadBook() {
        book = db.getBookById(bookId)
        book?.let { updateUI(it) }
    }

    private fun updateUI(book: Book) {
        binding.tvDetailTitle.text = book.title
        binding.tvDetailAuthor.text = book.author
        binding.tvDetailInfo.text = "${book.category} \u00b7 ${book.totalPages} hal \u00b7 \u2b50 ${book.rating}"
        binding.tvProgressPercent.text = "${book.progressPercent}%"
        binding.tvPageInfo.text = "Halaman ${book.currentPage} dari ${book.totalPages}"
        binding.tvNotes.text = book.notes
        binding.seekBarProgress.max = book.totalPages
        binding.seekBarProgress.progress = book.currentPage

        // Status
        updateStatusUI(book.status)
    }

    private fun updateStatus(status: String) {
        book?.let {
            val updated = it.copy(status = status)
            book = updated
            db.updateBook(updated)
            updateStatusUI(status)
            Toast.makeText(this, "Status: $status", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStatusUI(status: String) {
        binding.btnMauDibaca.setBackgroundResource(if (status == "Mau Dibaca") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnMauDibaca.setTextColor(if (status == "Mau Dibaca") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.btnSedang.setBackgroundResource(if (status == "Sedang") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnSedang.setTextColor(if (status == "Sedang") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.btnSelesai.setBackgroundResource(if (status == "Selesai") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.btnSelesai.setTextColor(if (status == "Selesai") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))
    }

    private fun showOptionsMenu() {
        val options = arrayOf("Edit Buku", "Hapus Buku", "Mulai Sesi Baca")
        AlertDialog.Builder(this)
            .setTitle(book?.title ?: "Opsi")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(this, EditBukuActivity::class.java)
                        intent.putExtra("book_id", bookId)
                        startActivity(intent)
                    }
                    1 -> {
                        AlertDialog.Builder(this)
                            .setTitle("Hapus Buku")
                            .setMessage("Yakin ingin menghapus buku ini?")
                            .setPositiveButton("Hapus") { _, _ ->
                                db.deleteBook(bookId)
                                Toast.makeText(this, "Buku dihapus", Toast.LENGTH_SHORT).show()
                                finish()
                            }
                            .setNegativeButton("Batal", null)
                            .show()
                    }
                    2 -> {
                        val intent = Intent(this, SesiBacaActivity::class.java)
                        intent.putExtra("book_id", bookId)
                        startActivity(intent)
                    }
                }
            }
            .show()
    }
}
