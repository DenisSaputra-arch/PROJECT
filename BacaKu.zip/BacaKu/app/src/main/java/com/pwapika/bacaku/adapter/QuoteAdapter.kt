package com.pwapika.bacaku.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pwapika.bacaku.R
import com.pwapika.bacaku.data.Quote

class QuoteAdapter(private val quotes: List<Quote>) :
    RecyclerView.Adapter<QuoteAdapter.QuoteViewHolder>() {

    class QuoteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvType: TextView = itemView.findViewById(R.id.tvQuoteType)
        val tvPage: TextView = itemView.findViewById(R.id.tvPageNum)
        val tvContent: TextView = itemView.findViewById(R.id.tvQuoteContent)
        val tvBookName: TextView = itemView.findViewById(R.id.tvBookName)
        val tvAuthorName: TextView = itemView.findViewById(R.id.tvAuthorName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuoteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_quote, parent, false)
        return QuoteViewHolder(view)
    }

    override fun onBindViewHolder(holder: QuoteViewHolder, position: Int) {
        val quote = quotes[position]
        holder.tvType.text = quote.type.uppercase()
        holder.tvPage.text = "Hal. ${quote.pageNumber}"
        holder.tvContent.text = "\u201c${quote.content}\u201d"
        holder.tvBookName.text = quote.bookTitle
        holder.tvAuthorName.text = quote.bookAuthor

        // Type badge color
        val badgeRes = if (quote.type == "kutipan") R.drawable.bg_badge_brand else R.drawable.bg_badge_sage
        holder.tvType.setBackgroundResource(badgeRes)
    }

    override fun getItemCount(): Int = quotes.size
}
