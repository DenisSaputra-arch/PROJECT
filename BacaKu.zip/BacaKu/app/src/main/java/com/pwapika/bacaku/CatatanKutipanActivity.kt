package com.pwapika.bacaku

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.pwapika.bacaku.adapter.QuoteAdapter
import com.pwapika.bacaku.data.Quote
import com.pwapika.bacaku.data.SQLiteHelper
import com.pwapika.bacaku.databinding.ActivityCatatanKutipanBinding

class CatatanKutipanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCatatanKutipanBinding
    private lateinit var db: SQLiteHelper
    private var currentTab = "Semua"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCatatanKutipanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SQLiteHelper(this)

        setupTabs()
        loadQuotes()

        binding.btnBack.setOnClickListener { finish() }

        binding.btnAdd.setOnClickListener {
            Toast.makeText(this, "Tambah catatan baru", Toast.LENGTH_SHORT).show()
        }

        binding.etSearch.setOnEditorActionListener { _, _, _ ->
            searchQuotes(binding.etSearch.text.toString())
            true
        }
    }

    private fun setupTabs() {
        binding.tabSemua.setOnClickListener { switchTab("Semua") }
        binding.tabKutipan.setOnClickListener { switchTab("kutipan") }
        binding.tabCatatan.setOnClickListener { switchTab("catatan") }
    }

    private fun switchTab(tab: String) {
        currentTab = tab
        binding.tabSemua.setBackgroundResource(if (tab == "Semua") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabSemua.setTextColor(if (tab == "Semua") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabKutipan.setBackgroundResource(if (tab == "kutipan") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabKutipan.setTextColor(if (tab == "kutipan") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabCatatan.setBackgroundResource(if (tab == "catatan") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabCatatan.setTextColor(if (tab == "catatan") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        loadQuotes()
    }

    private fun loadQuotes() {
        val quotes = if (currentTab == "Semua") {
            db.getAllQuotes()
        } else {
            db.getQuotesByType(currentTab)
        }

        if (quotes.isEmpty()) {
            // Sample data
            val sampleQuotes = listOf(
                Quote(id = 1, bookId = 1, bookTitle = "Atomic Habits", bookAuthor = "James Clear", type = "kutipan", content = "You do not rise to the level of your goals. You fall to the level of your systems.", pageNumber = 142, tags = "#PRODUKTIVITAS"),
                Quote(id = 2, bookId = 1, bookTitle = "Atomic Habits", bookAuthor = "James Clear", type = "catatan", content = "Konsep \"habit stacking\" \u2014 gabungkan kebiasaan baru di belakang kebiasaan lama biar lebih gampang konsisten.", pageNumber = 88, tags = "#PRODUKTIVITAS,#KEBIASAAN"),
                Quote(id = 3, bookId = 2, bookTitle = "Psychology of Money", bookAuthor = "Morgan Housel", type = "kutipan", content = "Spending money to show people how much money you have is the fastest way to have less money.", pageNumber = 23, tags = "")
            )
            binding.rvQuotes.layoutManager = LinearLayoutManager(this)
            binding.rvQuotes.adapter = QuoteAdapter(sampleQuotes)
        } else {
            binding.rvQuotes.layoutManager = LinearLayoutManager(this)
            binding.rvQuotes.adapter = QuoteAdapter(quotes)
        }
    }

    private fun searchQuotes(query: String) {
        if (query.isEmpty()) {
            loadQuotes()
            return
        }
        val quotes = db.searchQuotes(query)
        binding.rvQuotes.layoutManager = LinearLayoutManager(this)
        binding.rvQuotes.adapter = QuoteAdapter(quotes)
    }
}
