package com.pwapika.bacaku

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.databinding.ActivityTargetBacaBinding
import com.pwapika.bacaku.util.SharedPrefHelper

class TargetBacaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTargetBacaBinding
    private lateinit var prefs: SharedPrefHelper
    private var booksPerMonth = 4

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTargetBacaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = SharedPrefHelper(this)

        setupPeriodTabs()
        setupSeekBar()
        setupCounter()

        binding.btnBack.setOnClickListener { finish() }

        binding.btnSave.setOnClickListener {
            val target = booksPerMonth * 12
            prefs.setYearlyTarget(target)
            Toast.makeText(this, "Target disimpan: $target buku/tahun", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupPeriodTabs() {
        binding.tabHarian.setOnClickListener { selectPeriod("Harian") }
        binding.tabMingguan.setOnClickListener { selectPeriod("Mingguan") }
        binding.tabTahunan.setOnClickListener { selectPeriod("Tahunan") }
    }

    private fun selectPeriod(period: String) {
        binding.tabHarian.setBackgroundResource(if (period == "Harian") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabHarian.setTextColor(if (period == "Harian") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabMingguan.setBackgroundResource(if (period == "Mingguan") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabMingguan.setTextColor(if (period == "Mingguan") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))

        binding.tabTahunan.setBackgroundResource(if (period == "Tahunan") R.drawable.bg_tab_selected else R.drawable.bg_tab_unselected)
        binding.tabTahunan.setTextColor(if (period == "Tahunan") resources.getColor(android.R.color.white) else resources.getColor(R.color.ink_2))
    }

    private fun setupSeekBar() {
        binding.seekBarMinutes.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val minutes = 5 + (progress * 55 / 100)
                binding.tvMinutes.text = "$minutes menit"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupCounter() {
        binding.btnMinus.setOnClickListener {
            if (booksPerMonth > 1) {
                booksPerMonth--
                updateCounter()
            }
        }

        binding.btnPlus.setOnClickListener {
            if (booksPerMonth < 20) {
                booksPerMonth++
                updateCounter()
            }
        }
        updateCounter()
    }

    private fun updateCounter() {
        binding.tvBookCount.text = booksPerMonth.toString()
        val yearly = booksPerMonth * 12
        val minutes = yearly * 30 * 30 // rough estimate
        binding.tvEstimation.text = "\u2248 $yearly buku / tahun"
        binding.tvEstMinutes.text = "Setara $minutes menit baca"
    }
}
