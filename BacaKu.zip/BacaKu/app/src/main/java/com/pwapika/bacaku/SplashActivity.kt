package com.pwapika.bacaku

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.pwapika.bacaku.util.SharedPrefHelper

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val prefs = SharedPrefHelper(this)

        Handler(Looper.getMainLooper()).postDelayed({
            when {
                !prefs.isOnboardingDone() -> {
                    startActivity(Intent(this, OnboardingActivity::class.java))
                }
                !prefs.isLoggedIn() -> {
                    startActivity(Intent(this, LoginActivity::class.java))
                }
                else -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                }
            }
            finish()
        }, 1800)
    }
}
