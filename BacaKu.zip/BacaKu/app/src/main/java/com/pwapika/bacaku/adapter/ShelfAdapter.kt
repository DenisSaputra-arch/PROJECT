package com.pwapika.bacaku.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pwapika.bacaku.R
import com.pwapika.bacaku.data.Book

class ShelfAdapter(
    private val books: List<Book>,
    private val onClick: (Book) -> Unit
) : RecyclerView.Adapter<ShelfAdapter.ShelfViewHolder>() {

    class ShelfViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flCover: FrameLayout = itemView.findViewById(R.id.flCover)
        val tvCoverTitle: TextView = itemView.findViewById(R.id.tvCoverTitle)
        val tvBookTitle: TextView = itemView.findViewById(R.id.tvBookTitle)
        val tvBookAuthor: TextView = itemView.findViewById(R.id.tvBookAuthor)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShelfViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_book_vertical, parent, false)
        return ShelfViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShelfViewHolder, position: Int) {
        val book = books[position]

        holder.tvBookTitle.text = book.title
        holder.tvBookAuthor.text = book.author
        holder.tvCoverTitle.text = book.title.replace(" ", "\n")

        val coverRes = when (book.coverColor) {
            "sage" -> R.drawable.bg_cover_sage
            "navy" -> R.drawable.bg_cover_navy
            "plum" -> R.drawable.bg_cover_plum
            "mustard" -> R.drawable.bg_cover_mustard
            "rust" -> R.drawable.bg_cover_rust
            "teal" -> R.drawable.bg_cover_teal
            "ink" -> R.drawable.bg_cover_ink
            else -> R.drawable.bg_cover_brown
        }
        holder.flCover.setBackgroundResource(coverRes)

        holder.itemView.setOnClickListener { onClick(book) }
    }

    override fun getItemCount(): Int = books.size
}
