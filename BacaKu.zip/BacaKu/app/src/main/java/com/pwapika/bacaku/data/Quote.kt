package com.pwapika.bacaku.data

data class Quote(
    val id: Long = 0,
    val bookId: Long,
    val bookTitle: String = "",
    val bookAuthor: String = "",
    val type: String = "kutipan", // "kutipan" atau "catatan"
    val content: String,
    val pageNumber: Int = 0,
    val tags: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
